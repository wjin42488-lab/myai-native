// MY AI 原生推理桥接（JNI + llama.cpp）
//
// 提供给 Java 层 com.myai.assistant.NativeBridge 的 7 个静态 native 方法：
//   nativeLoadModel / nativeGenerate / nativeReset / nativeStop /
//   nativeRelease / nativeLastError / nativeSystemInfo
//
// 设计要点：
//   * 原生层持有一个全局引擎（模型 + 上下文 + 采样器 + 对话历史）。
//   * 对话历史保存在原生层；每次只把“新增的那一段”提示词送进模型（复用 KV cache）。
//   * 流式输出：每产生一段完整的 UTF-8 文本就回调 Java（避免中文被拆成半个字符）。
//   * 停止生成：nativeStop() 只置一个原子标志，生成循环每个 token 检查一次。
//
// 对应 llama.cpp 2025 年末以后的 C API（llama_model_load_from_file /
// llama_init_from_model / llama_memory_clear 等）。GitHub Actions 会自动挑选
// 一个 tag 编译，失败时自动换下一个候选。

#include <jni.h>
#include <android/log.h>

#include <algorithm>
#include <atomic>
#include <cstring>
#include <exception>
#include <mutex>
#include <string>
#include <vector>

#include "llama.h"

#define LOG_TAG "MYAI-Native"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

struct Msg {
    std::string role;
    std::string content;
};

struct Engine {
    std::mutex mtx;                 // 保护下面所有状态（加载/生成/重置互斥）
    std::atomic<bool> stop{false};  // 由 nativeStop 置位，不需要拿锁
    bool backend_ready = false;

    llama_model* model = nullptr;
    llama_context* ctx = nullptr;
    llama_sampler* smpl = nullptr;
    const llama_vocab* vocab = nullptr;

    int n_ctx = 0;
    int n_batch = 512;
    int n_past = 0;                 // 已经写入 KV cache 的 token 数

    std::string tmpl;               // 模型自带的聊天模板（可能为空）
    std::string system;             // 系统提示词
    std::vector<Msg> history;       // 完整对话历史
    size_t prev_len = 0;            // 上一轮结束时，模板渲染出的文本长度
    std::string last_error;
};

Engine g;

// ---------------------------------------------------------------- 工具函数

void llama_log_cb(ggml_log_level level, const char* text, void* /*user*/) {
    int prio = ANDROID_LOG_INFO;
    if (level == GGML_LOG_LEVEL_ERROR) prio = ANDROID_LOG_ERROR;
    else if (level == GGML_LOG_LEVEL_WARN) prio = ANDROID_LOG_WARN;
    else if (level == GGML_LOG_LEVEL_DEBUG) prio = ANDROID_LOG_DEBUG;
    __android_log_write(prio, LOG_TAG, text);
}

std::string to_std(JNIEnv* env, jstring s) {
    if (!s) return std::string();
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r = c ? c : "";
    if (c) env->ReleaseStringUTFChars(s, c);
    return r;
}

jstring to_jstr(JNIEnv* env, const std::string& s) {
    // 这里只会传入本文件里写死的中文/ASCII 提示，均为合法 (modified) UTF-8
    return env->NewStringUTF(s.c_str());
}

// 返回 s 中“不以半个多字节字符结尾”的最长前缀长度。
size_t utf8_complete_prefix(const std::string& s) {
    const size_t n = s.size();
    if (n == 0) return 0;
    const size_t max_back = std::min<size_t>(3, n);
    for (size_t back = 1; back <= max_back; ++back) {
        const unsigned char c = static_cast<unsigned char>(s[n - back]);
        if ((c & 0xC0) == 0x80) continue;  // 续字节，继续往前找首字节
        size_t need = 1;
        if ((c & 0xE0) == 0xC0) need = 2;
        else if ((c & 0xF0) == 0xE0) need = 3;
        else if ((c & 0xF8) == 0xF0) need = 4;
        if (need > back) return n - back;  // 字符不完整，先留着
        return n;
    }
    return n;
}

void init_backend_once() {
    if (g.backend_ready) return;
    llama_log_set(llama_log_cb, nullptr);
    llama_backend_init();
    g.backend_ready = true;
}

// 读取模型自带的聊天模板（GGUF 元数据 tokenizer.chat_template）；空字符串表示没有。
// 用元数据接口而不是 llama_model_chat_template()，以兼容不同版本的签名。
std::string read_chat_template(const llama_model* model) {
    std::vector<char> buf(32768);
    int32_t n = llama_model_meta_val_str(model, "tokenizer.chat_template", buf.data(), buf.size());
    if (n < 0) return std::string();
    if (static_cast<size_t>(n) >= buf.size()) {
        buf.resize(static_cast<size_t>(n) + 1);
        n = llama_model_meta_val_str(model, "tokenizer.chat_template", buf.data(), buf.size());
        if (n < 0) return std::string();
    }
    return std::string(buf.data(), static_cast<size_t>(n));
}

// 模板无法识别时的兜底格式
std::string fallback_format(const std::vector<Msg>& h, bool add_ass) {
    const bool phi = g.tmpl.find("<|end|>") != std::string::npos &&
                     g.tmpl.find("<|assistant|>") != std::string::npos;
    std::string s;
    for (const auto& m : h) {
        if (phi) s += "<|" + m.role + "|>" + m.content + "<|end|>";
        else s += "<|im_start|>" + m.role + "\n" + m.content + "<|im_end|>\n";
    }
    if (add_ass) s += phi ? "<|assistant|>" : "<|im_start|>assistant\n";
    return s;
}

void apply_template(const std::vector<Msg>& h, bool add_ass, std::string& out) {
    std::vector<llama_chat_message> msgs;
    msgs.reserve(h.size());
    size_t total = 0;
    for (const auto& m : h) {
        llama_chat_message cm;
        cm.role = m.role.c_str();
        cm.content = m.content.c_str();
        msgs.push_back(cm);
        total += m.role.size() + m.content.size() + 64;
    }
    const char* t = g.tmpl.empty() ? nullptr : g.tmpl.c_str();
    std::vector<char> buf(total * 2 + 1024);
    int n = llama_chat_apply_template(t, msgs.data(), msgs.size(), add_ass,
                                      buf.data(), static_cast<int32_t>(buf.size()));
    if (n > static_cast<int>(buf.size())) {
        buf.resize(static_cast<size_t>(n) + 16);
        n = llama_chat_apply_template(t, msgs.data(), msgs.size(), add_ass,
                                      buf.data(), static_cast<int32_t>(buf.size()));
    }
    if (n < 0) {
        LOGW("llama_chat_apply_template 不支持该模板，改用兜底格式");
        out = fallback_format(h, add_ass);
        return;
    }
    out.assign(buf.data(), static_cast<size_t>(n));
}

// 清空 KV cache 与历史（保留系统提示词）。调用时必须已持有 g.mtx。
void reset_conversation_locked() {
    if (g.ctx) llama_memory_clear(llama_get_memory(g.ctx), true);
    g.n_past = 0;
    g.prev_len = 0;
    g.history.clear();
    if (!g.system.empty()) g.history.push_back({"system", g.system});
}

void release_locked() {
    if (g.smpl) { llama_sampler_free(g.smpl); g.smpl = nullptr; }
    if (g.ctx) { llama_free(g.ctx); g.ctx = nullptr; }
    if (g.model) { llama_model_free(g.model); g.model = nullptr; }
    g.vocab = nullptr;
    g.n_ctx = 0;
    g.n_past = 0;
    g.prev_len = 0;
    g.tmpl.clear();
    g.history.clear();
}

// 把一段 UTF-8 字节回调给 Java：boolean onToken(byte[] utf8)
struct Emitter {
    JNIEnv* env;
    jobject cb;
    jmethodID mid;
    bool alive = true;

    bool emit(const char* data, size_t len) {
        if (!alive || len == 0) return alive;
        jbyteArray arr = env->NewByteArray(static_cast<jsize>(len));
        if (!arr) { alive = false; return false; }
        env->SetByteArrayRegion(arr, 0, static_cast<jsize>(len),
                                reinterpret_cast<const jbyte*>(data));
        const jboolean keep = env->CallBooleanMethod(cb, mid, arr);
        env->DeleteLocalRef(arr);
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            alive = false;
            return false;
        }
        if (!keep) alive = false;
        return alive;
    }
};

// 真正的生成流程。返回空字符串表示成功，否则为错误提示。调用时必须已持有 g.mtx。
std::string run_generate(const std::string& user, int max_new, Emitter& em) {
    if (!g.ctx || !g.model || !g.vocab) return "模型尚未加载。";
    g.stop = false;

    // 1) 把用户消息加入历史，用模板渲染，只取新增部分
    g.history.push_back({"user", user});
    std::string formatted;
    apply_template(g.history, true, formatted);
    const size_t from = std::min(g.prev_len, formatted.size());
    const std::string prompt = formatted.substr(from);

    // 2) 分词（首轮才加 BOS 等特殊 token）
    const bool first = (g.n_past == 0);
    const int need = -llama_tokenize(g.vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()),
                                     nullptr, 0, first, true);
    if (need <= 0) {
        g.history.pop_back();
        return "分词失败（提示词为空或模板渲染异常）。";
    }
    std::vector<llama_token> toks(static_cast<size_t>(need));
    const int n_tok = llama_tokenize(g.vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()),
                                     toks.data(), static_cast<int32_t>(toks.size()), first, true);
    if (n_tok < 0) {
        g.history.pop_back();
        return "分词失败。";
    }
    toks.resize(static_cast<size_t>(n_tok));

    // 3) 上下文是否放得下
    if (g.n_past + n_tok + 16 > g.n_ctx) {
        g.history.pop_back();
        return "上下文已满（n_ctx=" + std::to_string(g.n_ctx) +
               "）。请点击「清空」开始新对话。";
    }
    const int budget = std::min(max_new, g.n_ctx - g.n_past - n_tok - 1);

    // 4) 分块处理提示词
    for (int i = 0; i < n_tok; i += g.n_batch) {
        if (g.stop) {
            reset_conversation_locked();
            return "已停止（提示词处理阶段），本轮对话上下文已重置。";
        }
        const int n = std::min(g.n_batch, n_tok - i);
        llama_batch batch = llama_batch_get_one(toks.data() + i, n);
        if (llama_decode(g.ctx, batch) != 0) {
            reset_conversation_locked();
            return "推理失败：llama_decode 返回错误，已重置对话。";
        }
        g.n_past += n;
    }

    // 5) 逐 token 采样
    std::string response;
    std::string pending;  // 还没凑成完整 UTF-8 字符的字节
    int produced = 0;
    char piece[512];
    while (produced < budget) {
        if (g.stop) break;

        llama_token tok = llama_sampler_sample(g.smpl, g.ctx, -1);

        if (llama_vocab_is_eog(g.vocab, tok)) {
            // 结束符也写入 KV，保持后续多轮对话的格式一致
            if (g.n_past < g.n_ctx) {
                llama_batch eb = llama_batch_get_one(&tok, 1);
                if (llama_decode(g.ctx, eb) == 0) g.n_past += 1;
            }
            break;
        }

        int n = llama_token_to_piece(g.vocab, tok, piece, static_cast<int32_t>(sizeof(piece)), 0, true);
        if (n < 0) n = 0;
        bool want_stop = false;
        if (n > 0) {
            response.append(piece, static_cast<size_t>(n));
            pending.append(piece, static_cast<size_t>(n));
            const size_t k = utf8_complete_prefix(pending);
            if (k > 0) {
                if (!em.emit(pending.data(), k)) want_stop = true;
                pending.erase(0, k);
            }
        }

        llama_batch batch = llama_batch_get_one(&tok, 1);
        if (llama_decode(g.ctx, batch) != 0) {
            if (!pending.empty()) em.emit(pending.data(), pending.size());
            reset_conversation_locked();
            return "推理失败：llama_decode 返回错误，已重置对话。";
        }
        g.n_past += 1;
        ++produced;
        if (want_stop) break;
    }
    if (!pending.empty()) em.emit(pending.data(), pending.size());

    // 6) 记录助手回复，并更新“已处理长度”
    g.history.push_back({"assistant", response});
    std::string full;
    apply_template(g.history, false, full);
    g.prev_len = full.size();
    return std::string();
}

}  // namespace

// ====================================================================== JNI

extern "C" JNIEXPORT jboolean JNICALL
Java_com_myai_assistant_NativeBridge_nativeLoadModel(JNIEnv* env, jclass /*cls*/,
                                                     jstring jpath, jint n_ctx_req,
                                                     jint n_threads_req) {
    std::lock_guard<std::mutex> lk(g.mtx);
    try {
        release_locked();
        g.last_error.clear();
        const std::string path = to_std(env, jpath);
        if (path.empty()) {
            g.last_error = "模型路径为空。";
            return JNI_FALSE;
        }
        init_backend_once();

        llama_model_params mp = llama_model_default_params();
        mp.n_gpu_layers = 0;   // 仅 CPU
        mp.use_mmap = true;
        mp.use_mlock = false;

        LOGI("加载模型：%s", path.c_str());
        g.model = llama_model_load_from_file(path.c_str(), mp);
        if (!g.model) {
            g.last_error =
                "llama_model_load_from_file 返回空：文件可能不完整/损坏，或当前 llama.cpp "
                "版本不支持该模型架构，或内存不足。详细原因见 logcat 标签 MYAI-Native。";
            return JNI_FALSE;
        }
        g.vocab = llama_model_get_vocab(g.model);

        int want = n_ctx_req > 0 ? n_ctx_req : 2048;
        const int train = llama_model_n_ctx_train(g.model);
        if (train > 0) want = std::min(want, train);
        g.n_batch = std::min(512, want);
        const int threads = n_threads_req > 0 ? n_threads_req : 4;

        llama_context_params cp = llama_context_default_params();
        cp.n_ctx = static_cast<uint32_t>(want);
        cp.n_batch = static_cast<uint32_t>(g.n_batch);
        cp.n_ubatch = static_cast<uint32_t>(g.n_batch);
        cp.n_threads = threads;
        cp.n_threads_batch = threads;
        cp.no_perf = true;
        g.ctx = llama_init_from_model(g.model, cp);
        if (!g.ctx) {
            release_locked();
            g.last_error = "创建推理上下文失败（多半是内存不足，可把上下文长度调小后重试）。";
            return JNI_FALSE;
        }
        g.n_ctx = static_cast<int>(llama_n_ctx(g.ctx));

        llama_sampler_chain_params sp = llama_sampler_chain_default_params();
        sp.no_perf = true;
        g.smpl = llama_sampler_chain_init(sp);
        llama_sampler_chain_add(g.smpl, llama_sampler_init_top_k(40));
        llama_sampler_chain_add(g.smpl, llama_sampler_init_top_p(0.9f, 1));
        llama_sampler_chain_add(g.smpl, llama_sampler_init_temp(0.7f));
        llama_sampler_chain_add(g.smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

        g.tmpl = read_chat_template(g.model);

        reset_conversation_locked();
        LOGI("模型已加载：n_ctx=%d threads=%d 模板=%s", g.n_ctx, threads,
             g.tmpl.empty() ? "(无，使用兜底)" : "模型自带");
        return JNI_TRUE;
    } catch (const std::exception& e) {
        release_locked();
        g.last_error = std::string("加载时发生 C++ 异常：") + e.what();
        LOGE("%s", g.last_error.c_str());
        return JNI_FALSE;
    } catch (...) {
        release_locked();
        g.last_error = "加载时发生未知 C++ 异常。";
        return JNI_FALSE;
    }
}

// 返回 null 表示成功；否则返回错误提示。
extern "C" JNIEXPORT jstring JNICALL
Java_com_myai_assistant_NativeBridge_nativeGenerate(JNIEnv* env, jclass /*cls*/,
                                                    jstring jprompt, jint max_new,
                                                    jobject callback) {
    if (!callback) return to_jstr(env, "回调对象为空。");
    jclass cb_cls = env->GetObjectClass(callback);
    jmethodID mid = env->GetMethodID(cb_cls, "onToken", "([B)Z");
    env->DeleteLocalRef(cb_cls);
    if (!mid) {
        env->ExceptionClear();
        return to_jstr(env, "找不到回调方法 onToken([B)Z。");
    }
    const std::string user = to_std(env, jprompt);

    std::lock_guard<std::mutex> lk(g.mtx);
    try {
        Emitter em{env, callback, mid};
        const std::string err = run_generate(user, max_new > 0 ? max_new : 512, em);
        if (err.empty()) return nullptr;
        return to_jstr(env, err);
    } catch (const std::exception& e) {
        reset_conversation_locked();
        return to_jstr(env, std::string("生成时发生 C++ 异常：") + e.what());
    } catch (...) {
        reset_conversation_locked();
        return to_jstr(env, "生成时发生未知 C++ 异常。");
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_myai_assistant_NativeBridge_nativeReset(JNIEnv* env, jclass /*cls*/, jstring jsystem) {
    const std::string sys = to_std(env, jsystem);
    std::lock_guard<std::mutex> lk(g.mtx);
    g.system = sys;
    reset_conversation_locked();
}

extern "C" JNIEXPORT void JNICALL
Java_com_myai_assistant_NativeBridge_nativeStop(JNIEnv* /*env*/, jclass /*cls*/) {
    g.stop = true;  // 不拿锁：生成线程正持有锁
}

extern "C" JNIEXPORT void JNICALL
Java_com_myai_assistant_NativeBridge_nativeRelease(JNIEnv* /*env*/, jclass /*cls*/) {
    g.stop = true;
    std::lock_guard<std::mutex> lk(g.mtx);
    release_locked();
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_myai_assistant_NativeBridge_nativeLastError(JNIEnv* env, jclass /*cls*/) {
    std::lock_guard<std::mutex> lk(g.mtx);
    return to_jstr(env, g.last_error);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_myai_assistant_NativeBridge_nativeSystemInfo(JNIEnv* env, jclass /*cls*/) {
    std::lock_guard<std::mutex> lk(g.mtx);
    std::string s;
    if (g.model) {
        char desc[256] = {0};
        llama_model_desc(g.model, desc, sizeof(desc));
        s += "模型：";
        s += desc;
        s += "\n上下文：" + std::to_string(g.n_ctx) + " tokens";
        s += "\n";
    }
    const char* info = llama_print_system_info();
    if (info) {
        // 只保留 ASCII 之外不会出现的内容；llama 的系统信息本身是纯 ASCII
        s += "CPU 特性：";
        s += info;
    }
    return to_jstr(env, s);
}
